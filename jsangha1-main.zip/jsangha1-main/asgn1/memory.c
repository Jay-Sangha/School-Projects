#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>

#define MAX_BUF 1024


void get(char *location) {
	int fd = open(location, O_RDONLY);

	ssize_t red;
	char buff[MAX_BUF];

	while ((red = read(fd, buff, sizeof(buff))) > 0) {
		write(STDOUT_FILENO, buff, red);
	}

	close(fd);
	exit(0);


}


void set(char *location, int content_len, char *contents) {

	int fd = open(location, O_WRONLY | O_CREAT | O_TRUNC, 0664);

	if (write(fd, contents, content_len) != content_len) {
		close(fd);
		fprintf(stderr, "Operation Failed\n");
		exit(1);
	}



	write(STDOUT_FILENO, "OK\n", 3);
	close(fd);
	exit(0);
}


int main(void) {

	char command[MAX_BUF];

	if (scanf("%1023s", command) != 1) {
		fprintf(stderr, "Invalid Command");
	}

	if (strcmp(command, "get") == 0) {
		char location[MAX_BUF];

		if (scanf("%1023s", location) != 1) {
				fprintf(stderr, "Invalid Command");
				}

		get(location);

	}


	else if (strcmp(command, "set") == 0) {
		char location[MAX_BUF];

		if (scanf("%1023s", location) != 1) {
			fprintf(stderr, "Invalid Command");
		}

		int content_len;

		if (scanf("%d", &content_len) != 1 || content_len < 0) {
			fprintf(stderr, "Invalid Command");
		}

		int total = 0;
		int readed = 0;
		char content[10048];

		while (total < content_len && (readed = read(STDIN_FILENO, content + total, content_len - total)) > 0) {
			total += readed;
		}

		set(location, total, content);

	}

	else {
		fprintf(stderr, "Invalid Command");
	}

	return 0;

}


